import { create } from "zustand";

export const useProductStore = create((set) => ({
  selectedProduct: {},
  setSelectedProduct: (product) => set({ selectedProduct: product }),
  productForm: { visible: false, type: "edit" },
  triggerFetch: false,
  setTriggerFetch: () => set((state) => ({ triggerFetch: !state.triggerFetch })),
  showForm: (type) => set({ productForm: { visible: true, type: type } }),
  hideForm: () => set((state) => ({ productForm: { ...state, visible: false } })),
}));
