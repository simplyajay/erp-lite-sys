import { useCallback } from "react";

export const useTableHandler = ({ state, fetchTableData }) => {
  const { page, sort, totalPages } = state;

  const searchItem = useCallback(
    (keyword = "") => {
      fetchTableData({ searchKeyword: keyword });
    },
    [fetchTableData]
  );

  const clearSearch = useCallback(
    (searchRef) => {
      if (searchRef.current) {
        searchRef.current.clearInput();
        fetchTableData();
      }
    },
    [fetchTableData]
  );

  const handleSort = useCallback(
    ({ by = "name", order = "asc", keyword = "" } = {}) => {
      if (by === "actions") return;
      const newSort = { by, order };
      fetchTableData({ searchKeyword: keyword, page, sort: newSort });
    },
    [fetchTableData, page]
  );

  const pageNext = useCallback(
    (keyword = "") => {
      if (page < totalPages) {
        const newPage = Number(page) + 1;
        fetchTableData({ searchKeyword: keyword, page: newPage, sort });
      }
    },
    [fetchTableData, page, totalPages, sort]
  );

  const pagePrev = useCallback(
    (keyword = "") => {
      if (page > 1) {
        const newPage = Number(page) - 1;
        fetchTableData({ searchKeyword: keyword, page: newPage, sort });
      }
    },
    [fetchTableData, page, sort]
  );

  return {
    searchItem,
    clearSearch,
    handleSort,
    pageNext,
    pagePrev,
  };
};
