import React from "react";

export const metadata = {
  robots: "noindex, nofollow", // Prevent search engines from indexing this page
  title: "Account",
};

const Account = () => {
  return <div className="w-full h-full bg-white">Account</div>;
};

export default Account;
