import React from "react";

const Documents = () => {
  return <div>Documents</div>;
};

export default Documents;
