"use client";
import React, { useState, useRef } from "react";
import Table from "@/components/table/Table";
import TableHead from "@/components/table/TableInfo";
import TableLayout from "@/components/table/TableLayout";
import TablePagination from "@/components/table/TablePagination";
import ActionButton from "@/components/table/TableAction";
import { useRouter } from "next/navigation";
import { getFetchOptions } from "@/api/options";
import { getSuppliers } from "@/api/supplier";
import { ExternalLinkIcon } from "@/components/icons/Icons";
import { useTableHandler } from "@/components/table/hooks/useTableHandler";

const Suppliers = ({ data }) => {
  const [state, setState] = useState({
    suppliers: data.suppliers,
    loading: false,
    searchKeyword: "",
    sort: { by: "name", order: "asc" },
    page: data.page,
    totalPages: data.totalPages,
  });

  const { suppliers, loading, page, totalPages, sort, searchKeyword } = state;

  const searchRef = useRef(null);
  const router = useRouter();

  const updateState = (updates) => {
    setState((prevState) => ({ ...prevState, ...updates }));
  };

  const fetchSuppliers = async ({
    page = 1,
    searchKeyword = "",
    sort = { by: "name", order: "asc" },
  } = {}) => {
    try {
      updateState({ loading: true });
      const fetchOptions = getFetchOptions("GET", null, true, false);
      fetchOptions.params = { page, sort: JSON.stringify(sort), searchKeyword };
      const data = await getSuppliers(fetchOptions);
      updateState({
        searchKeyword,
        sort,
        suppliers: data.suppliers,
        totalPages: data.totalPages,
        loading: false,
        page: data.page,
      });
    } catch (error) {
      console.error("Error on fetchSupplier at Layout ", error);
      updateState({ loading: true });
    }
  };

  const { searchItem, clearSearch, handleSort, pageNext, pagePrev } = useTableHandler({
    state,
    fetchTableData: fetchSuppliers,
  });

  const tableHeaders = [
    { name: "COMPANY NAME", key: "name" },
    { name: "DESCRIPTION", key: "description" },
    { name: "PHONE", key: "phone", object: "contact" },
    { name: "EMAIL", key: "email", object: "contact" },
  ];

  const tableActions = {
    name: "ACTIONS",
    key: "actions",
    components: [
      <ActionButton
        key={"goto"}
        onClick={(target) => router.push(`/suppliers/${target._id}`)}
        icon={<ExternalLinkIcon className="fill-current text-blue-500" />}
        text={"View"}
        customClass={"text-blue-500"}
      />,
    ],
  };

  return (
    <div className="h-full w-full flex flex-col lg:flex-row gap-5 md:gap-5 justify-between">
      <TableLayout loading={loading}>
        <TableHead
          title={"SUPPLIERS"}
          buttonText={"Add Supplier"}
          onButtonClick={() => console.log("test")}
          searchRef={searchRef}
          handleSearch={searchItem}
          handleSearchClear={clearSearch}
          searchKeyword={searchKeyword}
        />

        <Table
          loading={loading}
          headers={tableHeaders}
          bodies={suppliers}
          actions={tableActions}
          messageWhenEmpty={"There are no Suppliers"}
          sort={{ ...sort, searchKeyword }}
          handleSort={handleSort}
        />

        <TablePagination
          onPrevPage={() => pagePrev(searchKeyword)}
          onNextPage={() => pageNext(searchKeyword)}
          currentPage={page}
          totalPages={totalPages}
        />
      </TableLayout>
    </div>
  );
};

export default Suppliers;
