"use client";
import React, { useEffect, useRef, useState } from "react";
import TableLayout from "@/components/table/TableLayout";
import TableInfo from "@/components/table/TableInfo";
import TableNew from "@/components/table/TableNew";
import Pagination from "@/components/table/Pagination";
import ConfirmDialog from "@/components/dialogs/ConfirmDialog";
import { useTableHandler } from "@/components/table/hooks/useTableHandler";
import { getStockTableColumns } from "../config/table.config";
import { getDialogOptions } from "../config/dialog.config";
import { useProductStore } from "@/store/useProductStore";
import { getFetchOptions } from "@/api/options";
import { getProducts } from "@/api/products";
import { deleteProduct } from "@/api/products";
import { notify } from "@/components/toast/ToastProvider";

const StockTable = ({ data }) => {
  const searchRef = useRef(null);
  const ref = useRef(false);

  const [state, setState] = useState({
    products: data.products,
    page: data.page,
    totalPages: data.totalPages,
    sort: data.sort,
    searchKeyword: "",
    loading: false,
    deleting: false,
    showConfirmDialog: false,
  });

  const { products, page, totalPages, sort, searchKeyword, loading, deleting, showConfirmDialog } =
    state;

  const { selectedProduct, setSelectedProduct, showForm, triggerFetch } = useProductStore();

  const updateState = (updates) => {
    setState((prev) => ({ ...prev, ...updates }));
  };

  const fetchProducts = async ({
    page = 1,
    searchKeyword = "",
    sort = { by: "name", order: "asc" },
  } = {}) => {
    try {
      updateState({ loading: true });
      const fetchOptions = getFetchOptions("GET", null, true, false);
      fetchOptions.params = { page, sort: JSON.stringify(sort), searchKeyword };
      const data = await getProducts(fetchOptions);
      updateState({
        searchKeyword,
        sort,
        products: data.products,
        totalPages: data.totalPages,
        loading: false,
        page: data.page,
      });
    } catch (error) {
      console.error("Error", error.message);
    }
  };

  const handleDelete = async (selectedProduct) => {
    const fetchOptions = getFetchOptions("DELETE", null, true, false);
    updateState({ deleting: true });
    const data = await deleteProduct(fetchOptions, selectedProduct._id);
    notify(data.message);
    updateState({
      deleting: false,
      showConfirmDialog: false,
    });
  };

  const onEditClick = (product) => {
    setSelectedProduct(product);
    showForm("edit");
  };

  const onDeleteClick = (product) => {
    setSelectedProduct(product);
    updateState({ showConfirmDialog: true });
  };

  const dialogOptions = getDialogOptions({
    product: selectedProduct,
    handleCancel: () => updateState({ showConfirmDialog: false }),
    handleConfirm: () => {
      handleDelete(selectedProduct);
      fetchProducts();
    },
    deleting: deleting,
  });

  const tableColumns = getStockTableColumns({
    handleEdit: onEditClick,
    handleDelete: onDeleteClick,
  });

  useEffect(() => {
    if (!ref.current) {
      ref.current = true;
      return;
    }
    fetchProducts();
  }, [triggerFetch]);

  const { searchItem, clearSearch, handleSort, pageNext, pagePrev } = useTableHandler({
    state: { page, sort, totalPages },
    updateState: fetchProducts,
    fetchTableData: fetchProducts,
  });

  return (
    <div className="flex-1 overflow-auto">
      <TableLayout>
        <TableInfo
          title={"PRODUCTS"}
          buttonText={"Add Product"}
          onButtonClick={() => showForm("add")}
          searchRef={searchRef}
          handleSearch={searchItem}
          handleSearchClear={clearSearch}
          searchKeyword={searchKeyword}
        />
        <TableNew
          columns={tableColumns}
          data={products}
          sortSettings={sort}
          onSort={handleSort}
          loading={loading}
        />
        <Pagination
          handlePrevious={() => pagePrev(searchKeyword)}
          handleNext={() => pageNext(searchKeyword)}
          currentPage={page}
          totalPages={totalPages}
          loading={loading}
        />
      </TableLayout>

      {showConfirmDialog && <ConfirmDialog option={dialogOptions} />}
    </div>
  );
};

export default StockTable;
