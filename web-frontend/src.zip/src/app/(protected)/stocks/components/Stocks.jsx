"use client";
import React, { useEffect } from "react";
import StockForm from "./StockForm";
import StockTable from "./StockTable";
import { useProductStore } from "@/store/useProductStore";

const Stocks = ({ data }) => {
  const { updateState } = useProductStore();

  console.log(data);
  useEffect(() => {
    if (data) {
      updateState({ products: data.products });
    }
  }, [data]);

  return (
    <div className="h-full flex flex-col lg:flex-row gap-1 justify-between">
      <StockTable />
      <StockForm />
    </div>
  );
};

export default Stocks;
