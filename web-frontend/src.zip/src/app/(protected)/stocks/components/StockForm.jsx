"use client";
import React, { useState, useMemo } from "react";
import { createStockFormHandler } from "@/utils/stockForm.util";
import {
  getProductComponents,
  getProductFormValues,
  productFormLabels,
} from "@/utils/stockForm.util";
import BasicForm from "@/components/forms/basic-form/BasicForm";
import { FormLayout } from "@/components/forms/basic-form/FormLayout";
import { ClipLoader } from "react-spinners";
import { ProductSchema } from "@/utils/schema/product.validationSchema";
import { useProductStore } from "@/store/useProductStore";

const StockForm = () => {
  const [updating, setUpdating] = useState(false);

  const { selectedProduct, productForm, setTriggerFetch, hideForm } = useProductStore();

  const formValues = useMemo(() => {
    if (productForm.type === "edit") {
      return getProductFormValues(selectedProduct);
    } else {
      return getProductFormValues();
    }
  }, [selectedProduct, productForm.type]);

  const { onFormSubmit } = createStockFormHandler({
    formType: productForm.type,
    selectedProduct,
    setUpdating,
    trigger: setTriggerFetch,
    hideForm,
  });

  const formCancelProps = {
    text: "Cancel",
    onClick: hideForm,
  };

  const formSubmitProps = {
    text:
      productForm.type === "edit"
        ? updating
          ? "Saving"
          : "Save"
        : updating
        ? "Creating"
        : "Create",
    icon: updating && <ClipLoader color="#007d96" size={15} loading={updating} />,
  };

  const formComponents = getProductComponents(productForm.type);

  console.log(productForm.visible);
  return (
    productForm?.visible && (
      <div className={`lg:h-full lg:w-[30%] h-[40%]`}>
        <FormLayout
          title={productForm.type === "edit" ? "PRODUCT INFORMATION" : "NEW PRODUCT"}
          pageInfoVisible={productForm.visible}
        >
          <BasicForm
            values={formValues}
            onSubmit={onFormSubmit}
            cancelProps={formCancelProps}
            submitProps={formSubmitProps}
            components={formComponents}
            loading={updating ? true : false}
            validationSchema={ProductSchema}
            labels={productFormLabels}
          />
        </FormLayout>
      </div>
    )
  );
};

export default StockForm;
