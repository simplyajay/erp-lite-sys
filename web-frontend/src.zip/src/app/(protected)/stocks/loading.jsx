import React from "react";
import TableSkeleton from "@/components/table/TableSkeleton";

const loading = () => {
  return <TableSkeleton />;
};

export default loading;
