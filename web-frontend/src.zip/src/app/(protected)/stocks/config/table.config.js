import { EditIcon, DeleteIcon } from "@/components/icons/Icons";

export const getStockTableColumns = ({ handleEdit, handleDelete }) => [
  { key: "sku", head: "SKU", sortable: true, body: (row) => row.sku },
  { key: "name", head: "NAME", sortable: true, body: (row) => row.name },
  { key: "description", head: "DESCRIPTION", sortable: true, body: (row) => row.description },
  { key: "unitOfMeasurement", head: "UNIT", sortable: true, body: (row) => row.unitOfMeasurement },
  {
    key: "quantity",
    head: "QTY",
    sortable: true,
    body: (row) => row.quantity,
    align: "justify-end",
  },
  {
    key: "action",
    head: "ACTION",
    body: (row) => (
      <div className="flex flex-row gap-2">
        <button
          className={`p-1 rounded-sm hover:cursor-pointer`}
          key="edit"
          onClick={() => handleEdit(row)}
        >
          <EditIcon />
        </button>
        <button
          className={`p-1 rounded-sm hover:cursor-pointer`}
          key="delete"
          onClick={() => handleDelete(row)}
        >
          <DeleteIcon />
        </button>
      </div>
    ),
    align: "justify-center",
  },
];
