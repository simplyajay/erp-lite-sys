import { ClipLoader } from "react-spinners";

export const getDialogOptions = ({ product, handleCancel, handleConfirm, deleting }) => ({
  message: (
    <>
      You are about to <strong className="font-semibold text-red-500">DELETE</strong> {product.name}
    </>
  ),
  cancel: {
    placeholder: "Cancel",
    onCancel: () => handleCancel(),
  },
  confirm: {
    placeholder: deleting ? (
      <ClipLoader color="#007d96" size={20} className="border border-red-400" loading={deleting} />
    ) : (
      "Delete"
    ),
    onConfirm: () => handleConfirm(),
  },
});
