import React from "react";

const SalePage = () => {
  return <div>SalePage</div>;
};

export default SalePage;
