"use client";
import React from "react";

const NotFound = () => {
  return (
    <div className="text-sm bg-red-500">
      <h2>Page not Found</h2>
    </div>
  );
};

export default NotFound;
