"use client";
import React from "react";

const error = () => {
  return <div>error</div>;
};

export default error;
